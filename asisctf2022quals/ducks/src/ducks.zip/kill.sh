#!/bin/bash

docker kill ducks 2>/dev/null
